from .camvid import CamVid
from .cityscapes import Cityscapes
from .mapillary import Mapillary

__all__ = ['CamVid', 'Cityscapes', 'Mapillary']
